import styles from "./nav.module.css";

export default function Nav(){
    return <div className={styles.nav}>
        🍔 Foodapp
    </div>
}